const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults();

server.use(middlewares);
server.use(jsonServer.bodyParser);

server.use((req, res, next) => {
  if (req.method === 'POST') {
    const db = router.db; // lowdb instance
    const employees = db.get('employees').value();
    const lastItemId = employees.length > 0 ? Math.max(...employees.map(emp => emp.id)) : 0;
    req.body.id = lastItemId + 1;
  }
  next();
});

server.use(router);
server.listen(3000, () => {
  console.log('JSON Server is running');
});
