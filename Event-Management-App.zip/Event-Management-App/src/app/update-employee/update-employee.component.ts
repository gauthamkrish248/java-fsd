import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  employeeId: number | undefined;
  employee: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      console.log('Params:', params); // Log params for debugging
      this.employeeId = +params['id'];
      if (isNaN(this.employeeId)) {
        console.error('Invalid employee ID:', params['id']);
        return;
      }
      this.fetchEmployeeDetails();
    });
  }

  fetchEmployeeDetails() {
    if (!this.employeeId) {
      console.error('Employee ID is not defined.');
      return;
    }
    this.http.get<any>(`http://localhost:3000/employees/${this.employeeId}`)
      .subscribe(
        employee => {
          this.employee = employee;
        },
        error => {
          console.error('Error fetching employee details:', error);
        }
      );
  }

  updateEmployee() {
    if (!this.employee || !this.employeeId) {
      console.error('Employee data or ID is not available.');
      return;
    }
    const updatedEmployee = {
      first_name: this.employee.first_name,
      last_name: this.employee.last_name,
      email: this.employee.email
    };
    this.http.put(`http://localhost:3000/employees/${this.employeeId}`, updatedEmployee)
      .subscribe(
        () => {
          console.log('Employee updated successfully');
          alert('Employee updated successfully');
          this.router.navigate(['/employees']);
        },
        error => {
          console.error('Error updating employee:', error);
          alert('Error updating employee. Please try again later.');
        }
      );
  }
}
