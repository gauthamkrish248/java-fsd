import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;

@WebFilter("/FilterDemoServlet5")
public class LoggingFilter5 implements Filter {

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Log the request information
        System.out.println("LoggingFilter: Request received from " + request.getRemoteAddr());

        // Pass request along the filter chain
        chain.doFilter(request, response);
    }

    public void init(FilterConfig fConfig) throws ServletException {
        // Initialization code, if any
    }

    public void destroy() {
        // Cleanup code, if any
    }
}
