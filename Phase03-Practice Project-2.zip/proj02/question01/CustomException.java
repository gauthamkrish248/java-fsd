package com.proj02.question01;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
}
