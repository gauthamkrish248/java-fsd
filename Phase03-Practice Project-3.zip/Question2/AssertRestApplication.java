import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class AssertRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssertRestApplication.class, args);
    }

}

@RestController
@AllArgsConstructor
class SquareController {

    @PostMapping("/square")
    public ResponseEntity<SquareResult> square(@RequestBody SquareRequest request) {
        assert request.getNumber() > 0 : "Number should be greater than 0";

        int result = request.getNumber() * request.getNumber();
        assert result > 0 : "Result should be greater than 0";

        return ResponseEntity.ok(new SquareResult(result));
    }

}

@Data
@AllArgsConstructor
class SquareRequest {
    private int number;
}

@Data
@AllArgsConstructor
class SquareResult {
    private int result;
}
