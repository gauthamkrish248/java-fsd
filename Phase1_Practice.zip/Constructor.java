package Phase01.PracticeProjects.AssistedPractice;

import java.util.Scanner;

class Constructor {
    int num1;
    int num2;

    Constructor() {
        num1 = 0;
        num2 = 0;
    }

    Constructor(int a, int b) {
        num1 = a;
        num2 = b;
    }

    Constructor(Constructor obj) {
        num1 = obj.num1;
        num2 = obj.num2;
    }

    void display() {
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Constructor obj1 = new Constructor();
        System.out.println("Values using default constructor:");
        obj1.display();

        System.out.print("\nEnter num1 for parameterized constructor: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter num2 for parameterized constructor: ");
        int num2 = scanner.nextInt();
        Constructor obj2 = new Constructor(num1, num2);
        System.out.println("\nValues using parameterized constructor:");
        obj2.display();

        Constructor obj3 = new Constructor(obj2);
        System.out.println("\nValues using copy constructor:");
        obj3.display();

        scanner.close();
    }
}

