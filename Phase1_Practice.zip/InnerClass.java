package Phase01.PracticeProjects.AssistedPractice;

import java.util.Scanner;

class Outer {
    private int outerNum;

    Outer(int outerNum) {
        this.outerNum = outerNum;
    }

    class Inner {
        void display() {
            System.out.println("Value of outerNum in Inner class: " + outerNum);
        }
    }
}

public class InnerClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a value for outerNum: ");
        int num = scanner.nextInt();

        Outer outerObj = new Outer(num);

        Outer.Inner innerObj = outerObj.new Inner();

        innerObj.display();

        scanner.close();
    }
}
