package Phase01.PracticeProjects.AssistedPractice;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Maps {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Map<String, Integer> map = new HashMap<>();

        System.out.println("Enter key-value pairs to add to the HashMap (enter 'exit' as key to stop):");
        String key;
        while (!(key = scanner.nextLine()).equalsIgnoreCase("exit")) {
            System.out.print("Enter the value for key '" + key + "': ");
            int value = scanner.nextInt();
            scanner.nextLine(); 
            map.put(key, value);
        }

        System.out.println("\nElements of HashMap:");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        scanner.close();
    }
}
