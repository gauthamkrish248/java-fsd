package Phase01.PracticeProjects.AssistedPractice;

import java.util.Scanner;

public class MethodCalling {
    static int add(int a, int b) {
        return a + b;
    }

    static void subtract(int a, int b) {
        int result = a - b;
        System.out.println("Subtraction result: " + result);
    }

    static int multiply(int a, int b) {
        return a * b;
    }

    static void divide(int a, int b) {
        if (b != 0) {
            int result = a / b;
            System.out.println("Division result: " + result);
        } else {
            System.out.println("Cannot divide by zero.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first number: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter second number: ");
        int num2 = scanner.nextInt();

        int sum = add(num1, num2);
        System.out.println("Addition result: " + sum);

        subtract(num1, num2);

        int product = multiply(num1, num2);
        System.out.println("Multiplication result: " + product);

        divide(num1, num2);

        scanner.close();
    }
}
