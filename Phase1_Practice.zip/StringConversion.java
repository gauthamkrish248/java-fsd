package Phase01.PracticeProjects.AssistedPractice;

import java.util.Scanner;

public class StringConversion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = scanner.nextLine();

        System.out.println("\nOriginal String: " + str);

        StringBuffer stringBuffer = new StringBuffer(str);
        System.out.println("String converted to StringBuffer: " + stringBuffer);

        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("String converted to StringBuilder: " + stringBuilder);

        scanner.close();
    }
}
