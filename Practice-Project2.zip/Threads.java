package Phase01.PracticeProjects2;

class MyThread1 extends Thread {
 public void run() {
     System.out.println("Thread created by extending Thread class.");
 }
}

class MyThread2 implements Runnable {
 public void run() {
     System.out.println("Thread created by implementing Runnable interface.");
 }
}

public class Threads {
 public static void main(String[] args) {
     MyThread1 thread1 = new MyThread1();
     
     MyThread2 myRunnable = new MyThread2();
     Thread thread2 = new Thread(myRunnable);
     
     thread1.start();
     thread2.start();
 }
}
