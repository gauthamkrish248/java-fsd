package Phase01.PracticeProjects3;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] arr = {10, 2, 7, 5, 8, 3, 9, 1, 6, 4}; 
        
        System.out.println("Original unsorted array:");
        printArray(arr);
        
        Arrays.sort(arr); 
        
        System.out.println("\nSorted array:");
        printArray(arr);

        int fourthSmallest = findFourthSmallest(arr);
        System.out.println("\nFourth smallest element in the array: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("Array length is less than 4.");
            return -1; 
        }

        return arr[3]; 
    }

    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}

